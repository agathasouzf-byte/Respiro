# Jogo de Cartas — Clube do Livro Respiro

Abra `index.html` no navegador para testar.

Para transformar em um link público, publique esta pasta em um serviço de hospedagem de páginas estáticas, como GitHub Pages, Netlify ou Vercel.

O jogo já inclui:
- sorteio aleatório;
- animação de embaralhamento;
- animação 3D de virar a carta;
- cartas sem repetição na mesma rodada;
- contador e barra de progresso;
- botão para recomeçar o baralho;
- layout responsivo para celular.
